package com.cts.healthcare.service;

import com.cts.healthcare.entity.Consultation;
import com.cts.healthcare.repository.ConsultationRepository;

import java.util.Optional;

import org.springframework.stereotype.Service;

@Service
public class ConsultationService {

    private final ConsultationRepository consultationRepository;

    public ConsultationService(ConsultationRepository consultationRepository) {
        this.consultationRepository = consultationRepository;
    }

    public void saveConsultation(Consultation consultation) {
        consultationRepository.save(consultation);
    }
    public Optional<Consultation> getConsultationByAppointmentId(Long appointmentId) {
        return consultationRepository.findByAppointmentAppointmentId(appointmentId);
    }
    
}
