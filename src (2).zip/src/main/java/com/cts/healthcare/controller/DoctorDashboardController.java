// package com.cts.healthcare.controller;

// import com.cts.healthcare.entity.Appointment;
// import com.cts.healthcare.entity.Consultation;
// import com.cts.healthcare.entity.User;
// import com.cts.healthcare.service.AppointmentService;
// import com.cts.healthcare.service.ConsultationService;
// import com.cts.healthcare.service.UserService;
// import com.cts.healthcare.config.TimeSlotConfig;

// import jakarta.servlet.http.HttpServletRequest;

// import org.springframework.stereotype.Controller;
// import org.springframework.ui.Model;
// import org.springframework.web.bind.annotation.*;

// import java.util.*;


// @Controller
// @RequestMapping("/doctor")
// public class DoctorDashboardController {

//     private final AppointmentService appointmentService;
//     private final UserService userService;
//     private final ConsultationService consultationService;
//     private final TimeSlotConfig timeSlotConfig;

//     public DoctorDashboardController(AppointmentService appointmentService, UserService userService, ConsultationService consultationService, TimeSlotConfig timeSlotConfig) {
//         this.appointmentService = appointmentService;
//         this.userService = userService;
//         this.consultationService = consultationService;
//         this.timeSlotConfig = timeSlotConfig;
//     }

//     @GetMapping("/upcoming-appointments")
//     public String getUpcomingAppointments(HttpServletRequest request, Model model) {
//         Long doctorId = (Long) request.getSession().getAttribute("userId");
//         if (doctorId != null) {
//             model.addAttribute("userId", doctorId);
//             model.addAttribute("timeSlots", timeSlotConfig.getTimeSlots());
//             List<Appointment> upcomingAppointments = appointmentService.getUpcomingAppointmentsForDoctor(doctorId);
//             model.addAttribute("appointments", upcomingAppointments);
//             model.addAttribute("view", "upcoming");
//             return "doctor-dashboard";
//         }
//         return "redirect:/login"; // Redirect to login page if user ID not found in session
//     }

//     @PostMapping("/complete-appointment")
//     public String completeAppointment(@RequestParam Long appointmentId, HttpServletRequest request, Model model) {
//         Long doctorId = (Long) request.getSession().getAttribute("userId");
//         if (doctorId != null) {
//             appointmentService.completeAppointment(appointmentId);
//             model.addAttribute("message", "Appointment marked as completed.");
//             return "redirect:/doctor/upcoming-appointments";
//         }
//         return "redirect:/login"; // Redirect to login page if user ID not found in session
//     }

//     @GetMapping("/completed-appointments")
//     public String getCompletedAppointments(HttpServletRequest request, Model model) {
//         Long doctorId = (Long) request.getSession().getAttribute("userId");
//         if (doctorId != null) {
//             model.addAttribute("userId", doctorId);
//             model.addAttribute("timeSlots", timeSlotConfig.getTimeSlots());
//             List<Appointment> completedAppointments = appointmentService.getCompletedAppointmentsForPatients(doctorId);
//             System.out.println("Completed Appointments: " + completedAppointments);
//             model.addAttribute("appointments", completedAppointments);
//             model.addAttribute("view", "completed");
//             return "doctor-dashboard";
//         }
//         return "redirect:/login"; // Redirect to login page if user ID not found in session
//     }

//     @GetMapping("/write-consultation")
//     public String writeConsultation(@RequestParam Long appointmentId, HttpServletRequest request, Model model) {
//         Long doctorId = (Long) request.getSession().getAttribute("userId");
//         if (doctorId != null) {
//             model.addAttribute("appointmentId", appointmentId);
//             return "write-consultation";
//         }
//         return "redirect:/login"; // Redirect to login page if user ID not found in session
//     }

//     @PostMapping("/submit-consultation")
// public String submitConsultation(@RequestParam Long appointmentId, @RequestParam String notes, @RequestParam String prescription, HttpServletRequest request, Model model) {
//     Long doctorId = (Long) request.getSession().getAttribute("userId");
//     if (doctorId != null) {
//         Optional<Appointment> optionalAppointment = appointmentService.giveByAppointmentId(appointmentId);
//         if (optionalAppointment.isPresent()) {
//             Appointment appointment = optionalAppointment.get();
//             Consultation consultation = new Consultation();
//             consultation.setAppointment(appointment);
//             consultation.setNotes(notes);
//             consultation.setPrescription(prescription);
//             consultationService.saveConsultation(consultation);
//             model.addAttribute("message", "Consultation notes submitted.");
//         } else {
//             model.addAttribute("message", "Appointment not found.");
//         }
//         return "redirect:/doctor/upcoming-appointments";
//     }
//     return "redirect:/login"; // Redirect to login page if user ID not found in session
// }


//     @GetMapping("/dashboard")
//     public String showDashboard(HttpServletRequest request, Model model) {
//         Long userId = (Long) request.getSession().getAttribute("userId");
//         if (userId != null) {
//             Optional<User> loggedInUser = userService.getUserById(userId);
//             if (loggedInUser.isPresent()) {
//                 model.addAttribute("loggedInUser", loggedInUser.get());
//                 model.addAttribute("userId", userId); // Add user ID to the model
               
//                 return "doctor-dashboard";
//             }
//         }
//         return "redirect:/login"; // Redirect to login page if user not found
//     }

//     @GetMapping("/logout")
//     public String logout(HttpServletRequest request) {
//         // Invalidate the session to log out the user
//         request.getSession().invalidate();
//         return "redirect:/login"; // Redirect to login page after logout
//     }
// }

package com.cts.healthcare.controller;

import com.cts.healthcare.entity.Appointment;
import com.cts.healthcare.entity.Consultation;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.service.AppointmentService;
import com.cts.healthcare.service.ConsultationService;
import com.cts.healthcare.service.UserService;
import com.cts.healthcare.config.TimeSlotConfig;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@Controller
@RequestMapping("/doctor")
public class DoctorDashboardController {

    private final AppointmentService appointmentService;
    private final UserService userService;
    private final ConsultationService consultationService;
    private final TimeSlotConfig timeSlotConfig;

    public DoctorDashboardController(AppointmentService appointmentService, UserService userService, ConsultationService consultationService, TimeSlotConfig timeSlotConfig) {
        this.appointmentService = appointmentService;
        this.userService = userService;
        this.consultationService = consultationService;
        this.timeSlotConfig = timeSlotConfig;
    }

    @GetMapping("/upcoming-appointments")
    public String getUpcomingAppointments(HttpServletRequest request, Model model) {
        Long doctorId = (Long) request.getSession().getAttribute("userId");
        if (doctorId != null) {
            model.addAttribute("userId", doctorId);
            model.addAttribute("timeSlots", timeSlotConfig.getTimeSlots());
            List<Appointment> upcomingAppointments = appointmentService.getUpcomingAppointmentsForDoctor(doctorId);
            model.addAttribute("appointments", upcomingAppointments);
            model.addAttribute("view", "upcoming");
            return "doctor-dashboard";
        }
        return "redirect:/login"; // Redirect to login page if user ID not found in session
    }

    @PostMapping("/complete-appointment")
    public String completeAppointment(@RequestParam Long appointmentId, HttpServletRequest request, Model model) {
        Long doctorId = (Long) request.getSession().getAttribute("userId");
        if (doctorId != null) {
            appointmentService.completeAppointment(appointmentId);
            model.addAttribute("message", "Appointment marked as completed.");
            return "redirect:/doctor/upcoming-appointments";
        }
        return "redirect:/login"; // Redirect to login page if user ID not found in session
    }
    @GetMapping("/completed-appointments")
    public String getCompletedAppointments(HttpServletRequest request, Model model) {
        Long patientId = (Long) request.getSession().getAttribute("userId");
        if (patientId != null) {
            model.addAttribute("userId", patientId);
            model.addAttribute("timeSlots", timeSlotConfig.getTimeSlots());
            List<Appointment> completedAppointments = appointmentService.getCompletedAppointmentsForDoctors(patientId);
            System.out.println("Completed Appointments: " + completedAppointments);
            model.addAttribute("appointments", completedAppointments);
            model.addAttribute("view", "completed");
            return "doctor-dashboard";
        }
        return "redirect:/login"; // Redirect to login page if user ID not found in session
    }

    @GetMapping("/write-consultation")
    public String writeConsultation(@RequestParam Long appointmentId, HttpServletRequest request, Model model) {
        Long doctorId = (Long) request.getSession().getAttribute("userId");
        if (doctorId != null) {
            model.addAttribute("appointmentId", appointmentId);
            return "write-consultation";
        }
        return "redirect:/login"; // Redirect to login page if user ID not found in session
    }

    @PostMapping("/submit-consultation")
public String submitConsultation(@RequestParam Long appointmentId, @RequestParam String notes, @RequestParam String prescription, HttpServletRequest request, Model model) {
    Long doctorId = (Long) request.getSession().getAttribute("userId");
    if (doctorId != null) {
        Optional<Appointment> optionalAppointment = appointmentService.giveByAppointmentId(appointmentId);
        if (optionalAppointment.isPresent()) {
            Appointment appointment = optionalAppointment.get();
            Consultation consultation = new Consultation();
            consultation.setAppointment(appointment);
            consultation.setNotes(notes);
            consultation.setPrescription(prescription);
            consultationService.saveConsultation(consultation);
            model.addAttribute("message", "Consultation notes submitted.");
        } else {
            model.addAttribute("message", "Appointment not found.");
        }
        return "redirect:/doctor/upcoming-appointments";
    }
    return "redirect:/login"; // Redirect to login page if user ID not found in session
}


    @GetMapping("/dashboard")
    public String showDashboard(HttpServletRequest request, Model model) {
        Long userId = (Long) request.getSession().getAttribute("userId");
        if (userId != null) {
            Optional<User> loggedInUser = userService.getUserById(userId);
            if (loggedInUser.isPresent()) {
                model.addAttribute("loggedInUser", loggedInUser.get());
                model.addAttribute("userId", userId); // Add user ID to the model
                return "doctor-dashboard";
            }
        }
        return "redirect:/login"; // Redirect to login page if user not found
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        // Invalidate the session to log out the user
        request.getSession().invalidate();
        return "redirect:/login"; // Redirect to login page after logout
    }
}
