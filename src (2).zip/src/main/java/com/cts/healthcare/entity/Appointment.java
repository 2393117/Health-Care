package com.cts.healthcare.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Data

public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "appointment_seq")
    @SequenceGenerator(name = "appointment_seq", sequenceName = "appointment_sequence", allocationSize = 1)
    private Long appointmentId;

    @ManyToOne
    @JoinColumn(name = "patientId")
    private User patient;

    @ManyToOne
    @JoinColumn(name = "doctorId")
    private User doctor;

    @Enumerated(EnumType.STRING)
    @Column(name = "time_slot", columnDefinition = "VARCHAR2(50)")
    private TimeSlot timeSlot;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "status", columnDefinition = "VARCHAR2(50)")
    private Status status;

    @Column(name = "app_date", columnDefinition = "DATE")
    private LocalDate date;
}


