package com.cts.healthcare.entity;

public enum Role {
    PATIENT, DOCTOR
}