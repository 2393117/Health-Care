package com.cts.healthcare.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_seq")
    @SequenceGenerator(name = "user_seq", sequenceName = "user_sequence", allocationSize = 1)
    @Column(name = "user_id")
    private Long Id;

    private String name;

    @Enumerated(EnumType.STRING)
    private Role role;

    private String specialization;

    @Column(unique = true)
    private String phoneNo;

    @Column(unique = true)
    private String email;

    private String password;
}


