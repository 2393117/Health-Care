package com.cts.healthcare.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter
public class Consultation {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "consultation_seq")
    @SequenceGenerator(name = "consultation_seq", sequenceName = "consultation_sequence", allocationSize = 1)
    private Long consultationId;

    @OneToOne
    @JoinColumn(name = "appointmentId")
    private Appointment appointment;

    private String notes;

    private String prescription;
}

