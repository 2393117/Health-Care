package com.cts.healthcare.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.healthcare.entity.BlockedTimeSlot;
import com.cts.healthcare.entity.User;

public interface BlockedTimeSlotRepository extends JpaRepository<BlockedTimeSlot, Long> {
    List<BlockedTimeSlot> findByDoctorAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
            User doctor, LocalDateTime endTime, LocalDateTime startTime);

    List<BlockedTimeSlot> findByDoctorAndStartTimeLessThanAndEndTimeGreaterThan(
            User doctor, LocalDateTime endTime, LocalDateTime startTime);

    List<BlockedTimeSlot> findByDoctorAndStartTimeGreaterThanEqualAndEndTimeLessThanEqual(
            User doctor, LocalDateTime startTime, LocalDateTime endTime);

    List<BlockedTimeSlot> findByDoctorAndStartTimeLessThanAndEndTimeGreaterThanEqual(
            User doctor, LocalDateTime endTime, LocalDateTime startTime);

    List<BlockedTimeSlot> findByDoctor(Optional<User> doctor);


}