package com.cts.healthcare.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.healthcare.entity.Consultation;
import java.util.Optional;
import org.springframework.stereotype.Repository;
@Repository
public interface ConsultationRepository  extends JpaRepository<Consultation, Long> {
    Optional<Consultation> findByAppointmentAppointmentId(Long appointmentId);
}
