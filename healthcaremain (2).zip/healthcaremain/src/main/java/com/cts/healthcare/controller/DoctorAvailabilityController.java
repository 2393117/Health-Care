package com.cts.healthcare.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.healthcare.entity.BlockedTimeSlot;
import com.cts.healthcare.repository.DoctorAvailabilityRepository;
import com.cts.healthcare.service.DoctorAvailabilityService;
import com.cts.healthcare.service.UserService;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.List;
import com.cts.healthcare.entity.User;

@Controller
public class DoctorAvailabilityController {

    private final DoctorAvailabilityRepository doctorAvailabilityRepository;

    @Autowired
    private DoctorAvailabilityService doctorAvailabilityService;

     // Assuming you have a DoctorService
    @Autowired
    private UserService userService;

    DoctorAvailabilityController(DoctorAvailabilityRepository doctorAvailabilityRepository) {
        this.doctorAvailabilityRepository = doctorAvailabilityRepository;
    }

    @GetMapping("/doctor/availability/block")
    public String showBlockAvailabilityForm(Model model) {
        model.addAttribute("blockedTimeSlot", new BlockedTimeSlot());
        return "doctor/block-availability-form";
    }

    @PostMapping("/doctor/availability/block")
    public String blockAvailability(@ModelAttribute BlockedTimeSlot blockedTimeSlot,
                                     @AuthenticationPrincipal UserDetails userDetails,
                                     @RequestParam("startTime") String startTimeStr,
                                     @RequestParam("endTime") String endTimeStr,
                                     Model model) {
        try {
           User doctor = userService.getUserByEmail(userDetails.getUsername()); // Assuming doctor info from auth

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
            LocalDateTime startTime = LocalDateTime.parse(startTimeStr, formatter);
            LocalDateTime endTime = LocalDateTime.parse(endTimeStr, formatter);

     doctorAvailabilityService.blockTimeSlot(doctor, startTime, endTime, blockedTimeSlot.getReason());
            model.addAttribute("successMessage", "Time slot blocked successfully.");
            return "doctor/block-availability-form"; // Or a confirmation page
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error blocking time slot: " + e.getMessage());
            return "doctor/block-availability-form";
        }
    }

    @GetMapping("/doctor/availability/blocked-slots")
public String viewBlockedSlots(@AuthenticationPrincipal UserDetails userDetails, Model model) {
    User doctor = userService.getUserByEmail(userDetails.getUsername()); // Corrected line
    List<BlockedTimeSlot> blockedSlots = doctorAvailabilityService.getBlockedTimeSlots(doctor);
    model.addAttribute("blockedSlots", blockedSlots);
    return "doctor/blocked-slots";
}
}