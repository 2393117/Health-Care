package com.cts.healthcare.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.Optional;

@Entity
@Table(name = "blocked_time_slots")
public class BlockedTimeSlot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "blocked_slot_id")
    private Long blockedSlotId;

    @ManyToOne
    @JoinColumn(name = "doctor_id", nullable = false)
    private User doctor;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    @Column(name = "reason")
    private String reason;

    // Constructors, Getters, and Setters

    public Long getBlockedSlotId() {
        return blockedSlotId;
    }

    public void setBlockedSlotId(Long blockedSlotId) {
        this.blockedSlotId = blockedSlotId;
    }

    public User getDoctor() {
        return doctor;
    }

    public void setDoctor(User doctor2) {
        this.doctor = doctor2;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}