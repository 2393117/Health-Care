package com.cts.healthcare.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.healthcare.entity.Role;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.repository.RoleRepository;
import com.cts.healthcare.repository.UserRepository;

@Service
public class UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    public UserService(UserRepository userRepository, RoleRepository roleRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public List<User> getUsersByRole(String roleName) {
        return userRepository.findByRole_Name(roleName);
    }

    @Transactional
    public User saveUser(User user) {
        try {
            logger.info("Attempting to save user: {}", user.getEmail());
            
            // Ensure the role exists
            Role role = roleRepository.findByName(user.getRole().getName())
                    .orElseThrow(() -> new IllegalArgumentException("Invalid role: " + user.getRole().getName()));
            
            logger.info("Found role: {}", role.getName());
            user.setRole(role);
            
            User savedUser = userRepository.save(user);
            logger.info("Successfully saved user with ID: {}", savedUser.getId());
            
            return savedUser;
        } catch (Exception e) {
            logger.error("Error saving user: {}", e.getMessage(), e);
            throw e;
        }
    }

    public List<User> getDoctorsBySpecialization(String specialization) {
        return userRepository.findBySpecialization(specialization);
    }

    // public Optional<User> getLoggedInUser() {
    //     return Optional.ofNullable(userRepository.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName()))
    //         .orElseThrow(() -> new IllegalArgumentException("User not found with email: " + SecurityContextHolder.getContext().getAuthentication().getName()));
    // }

    @Transactional
    public void initializeRoles() {
        if (roleRepository.count() == 0) {
            Role patientRole = new Role(Role.ROLE_PATIENT, "Patient role with basic access");
            Role doctorRole = new Role(Role.ROLE_DOCTOR, "Doctor role with medical access");
            roleRepository.save(patientRole);
            roleRepository.save(doctorRole);
        }
    }
}
