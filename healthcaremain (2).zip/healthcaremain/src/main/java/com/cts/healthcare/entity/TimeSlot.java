package com.cts.healthcare.entity;

import java.time.LocalTime;

public enum TimeSlot {
    NINE_AM(LocalTime.of(9, 0)),
    NINE_THIRTY_AM(LocalTime.of(9, 30)),
    TEN_AM(LocalTime.of(10, 0)),
    TEN_THIRTY_AM(LocalTime.of(10, 30)),
    ELEVEN_AM(LocalTime.of(11, 0)),
    ELEVEN_THIRTY_AM(LocalTime.of(11, 30)),
    TWELVE_PM(LocalTime.of(12, 0)),
    TWELVE_THIRTY_PM(LocalTime.of(12, 30)),
    ONE_PM(LocalTime.of(13, 0)),
    ONE_THIRTY_PM(LocalTime.of(13, 30)),
    TWO_PM(LocalTime.of(14, 0)),
    TWO_THIRTY_PM(LocalTime.of(14, 30)),
    THREE_PM(LocalTime.of(15, 0)),
    THREE_THIRTY_PM(LocalTime.of(15, 30)),
    FOUR_PM(LocalTime.of(16, 0)),
    FOUR_THIRTY_PM(LocalTime.of(16, 30)),
    FIVE_PM(LocalTime.of(17, 0));

    private final LocalTime time;

    TimeSlot(LocalTime time) {
        this.time = time;
    }

    public LocalTime getTime() {
        return time;
    }

    public boolean isBeforeNow() {
        return time.isBefore(LocalTime.now());
    }

    public boolean isAfterNow() {
        return time.isAfter(LocalTime.now());
    }
}