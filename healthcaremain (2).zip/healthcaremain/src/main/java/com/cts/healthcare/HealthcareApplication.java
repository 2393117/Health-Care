package com.cts.healthcare;

import com.cts.healthcare.entity.Role;
import com.cts.healthcare.repository.RoleRepository;
import com.cts.healthcare.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class HealthcareApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthcareApplication.class, args);
	}

	@Bean
	public CommandLineRunner initializeRoles(RoleRepository roleRepository, UserService userService) {
		return args -> {
			if (roleRepository.count() == 0) {
				Role patientRole = new Role(Role.ROLE_PATIENT, "Patient role with basic access");
				Role doctorRole = new Role(Role.ROLE_DOCTOR, "Doctor role with medical access");
				roleRepository.save(patientRole);
				roleRepository.save(doctorRole);
			}
		};
	}

}
