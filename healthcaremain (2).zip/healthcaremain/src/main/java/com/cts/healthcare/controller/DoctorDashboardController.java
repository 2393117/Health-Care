package com.cts.healthcare.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.healthcare.entity.Appointment;
import com.cts.healthcare.entity.Consultation;
import com.cts.healthcare.entity.TimeSlot;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.security.SecurityUtils;
import com.cts.healthcare.service.AppointmentService;
import com.cts.healthcare.service.ConsultationService;

import jakarta.servlet.http.HttpServletRequest;


@Controller
@RequestMapping("/doctor")
public class DoctorDashboardController {

    private final AppointmentService appointmentService;
    private final ConsultationService consultationService;
    private final SecurityUtils securityUtils;
    

    public DoctorDashboardController(AppointmentService appointmentService, ConsultationService consultationService, SecurityUtils securityUtils) {
        this.appointmentService = appointmentService;
        this.consultationService = consultationService;
        this.securityUtils = securityUtils;
    }

    @GetMapping("/upcoming-appointments")
    public String getUpcomingAppointments(Model model) {
        Long patientId = securityUtils.getCurrentUserId();
        if (patientId != null) {
            model.addAttribute("userId", patientId);
            model.addAttribute("timeSlots", TimeSlot.values()); // Use TimeSlot enum
            List<Appointment> upcomingAppointments = appointmentService.getUpcomingAppointmentsForDoctor(patientId);
            model.addAttribute("appointments", upcomingAppointments);
            model.addAttribute("view", "upcoming");
            return "doctor-dashboard";
        }
        return "redirect:/login";
    }

    @GetMapping("/completed-appointments")
    public String getCompletedAppointments(Model model) {
        Long patientId = securityUtils.getCurrentUserId();
        if (patientId != null) {
            model.addAttribute("userId", patientId);
            model.addAttribute("timeSlots", TimeSlot.values()); // Use TimeSlot enum
            List<Appointment> completedAppointments = appointmentService.getCompletedAppointmentsForDoctors(patientId);
            model.addAttribute("appointments", completedAppointments);
            model.addAttribute("view", "completed");
            return "doctor-dashboard";
        }
        return "redirect:/login";
    }


    @PostMapping("/complete-appointment")
    public String completeAppointment(@RequestParam Long appointmentId, HttpServletRequest request, Model model) {
        Long doctorId = securityUtils.getCurrentUserId();
        if (doctorId != null) {
            appointmentService.completeAppointment(appointmentId);
            model.addAttribute("message", "Appointment marked as completed.");
            return "redirect:/doctor/upcoming-appointments";
        }
        return "redirect:/login"; // Redirect to login page if user ID not found in session
    }

    @GetMapping("/write-consultation")
    public String writeConsultation(@RequestParam Long appointmentId, HttpServletRequest request, Model model) {
        Long doctorId = securityUtils.getCurrentUserId();
        if (doctorId != null) {
            model.addAttribute("appointmentId", appointmentId);
            return "write-consultation";
        }
        return "redirect:/login"; // Redirect to login page if user ID not found in session
    }

    @PostMapping("/submit-consultation")
    public String submitConsultation(@RequestParam Long appointmentId, @RequestParam String notes, @RequestParam String prescription, HttpServletRequest request, Model model) {
        Long doctorId = securityUtils.getCurrentUserId();
        if (doctorId != null) {
            Optional<Appointment> optionalAppointment = appointmentService.giveByAppointmentId(appointmentId);
            if (optionalAppointment.isPresent()) {
                Appointment appointment = optionalAppointment.get();
                Consultation consultation = new Consultation();
                consultation.setAppointment(appointment);
                consultation.setNotes(notes);
                consultation.setPrescription(prescription);
                consultationService.saveConsultation(consultation);
                model.addAttribute("message", "Consultation notes submitted.");
            } else {
                model.addAttribute("message", "Appointment not found.");
            }
            return "redirect:/doctor/upcoming-appointments";
        }
        return "redirect:/login"; // Redirect to login page if user ID not found in session
    }


    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        User currentUser = securityUtils.getCurrentUser();
        if (currentUser != null) {
            model.addAttribute("loggedInUser", currentUser);
            model.addAttribute("userId", currentUser.getId());
            model.addAttribute("timeSlots", TimeSlot.values()); // Use TimeSlot enum
            return "doctor-dashboard";
        }
        return "redirect:/login";
    }

}
