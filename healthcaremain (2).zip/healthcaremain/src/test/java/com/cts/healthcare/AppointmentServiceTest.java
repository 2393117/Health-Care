package com.cts.healthcare;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.healthcare.entity.Appointment;
import com.cts.healthcare.entity.DoctorAvailability;
import com.cts.healthcare.entity.Status;
import com.cts.healthcare.entity.TimeSlot;
import com.cts.healthcare.entity.User;

import com.cts.healthcare.repository.AppointmentRepository;
import com.cts.healthcare.repository.DoctorAvailabilityRepository;
import com.cts.healthcare.repository.UserRepository;
import com.cts.healthcare.service.AppointmentService;
@ExtendWith(MockitoExtension.class)
public class AppointmentServiceTest {

    @Mock
    private AppointmentRepository appointmentRepository;

    @Mock
    private DoctorAvailabilityRepository availabilityRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private AppointmentService appointmentService;

    @Test
    void testBookAppointment() {
        Appointment appointment = new Appointment();
        User doctor = new User();
        doctor.setId(1L);
        User patient = new User();
        patient.setId(2L);
        appointment.setDoctor(doctor);
        appointment.setPatient(patient);
        appointment.setDate(LocalDate.now());
        appointment.setTimeSlot(TimeSlot.FIVE_PM);

        when(userRepository.findById(1L)).thenReturn(Optional.of(doctor));
        when(userRepository.findById(2L)).thenReturn(Optional.of(patient));
        when(availabilityRepository.findByDoctorIdAndDateAndTimeSlot(1L, appointment.getDate(), appointment.getTimeSlot()))
            .thenReturn(Collections.emptyList());

        String result = appointmentService.bookAppointment(appointment);

        assertEquals("Appointment booked successfully!", result);

        DoctorAvailability newAvailability = new DoctorAvailability();
        newAvailability.setDoctor(doctor);
        newAvailability.setDate(appointment.getDate());
        newAvailability.setTimeSlot(appointment.getTimeSlot());

        verify(availabilityRepository).save(newAvailability);
        verify(appointmentRepository).save(appointment);
    }

    @Test
    void testCancelAppointment() {
        Appointment appointment = new Appointment();
        appointment.setAppointmentId(1L);
        User doctor = new User();
        doctor.setId(1L);
        appointment.setDoctor(doctor);
        appointment.setDate(LocalDate.now());
        appointment.setTimeSlot(TimeSlot.FIVE_PM);
        appointment.setStatus(Status.BOOKED);

        when(appointmentRepository.findByAppointmentId(1L)).thenReturn(Optional.of(appointment));

        String result = appointmentService.cancelAppointment(1L);

        assertEquals("Appointment cancelled successfully!", result);
        assertEquals(Status.CANCELLED, appointment.getStatus());
        verify(appointmentRepository).save(appointment);
        verify(availabilityRepository).deleteByDoctorIdAndDateAndTimeSlot(1L, appointment.getDate(), appointment.getTimeSlot());
    }

    @Test
    void testModifyAppointment() {
        Appointment appointment = new Appointment();
        appointment.setAppointmentId(1L);
        User doctor = new User();
        doctor.setId(1L);
        appointment.setDoctor(doctor);
        appointment.setDate(LocalDate.now());
        appointment.setTimeSlot(TimeSlot.FIVE_PM);
        appointment.setStatus(Status.BOOKED);

        LocalDate newDate = LocalDate.now().plusDays(1);
        TimeSlot newTimeSlot = TimeSlot.FIVE_PM;

        when(appointmentRepository.findById(1L)).thenReturn(Optional.of(appointment));
        when(availabilityRepository.findByDoctorIdAndDateAndTimeSlot(1L, newDate, newTimeSlot))
            .thenReturn(Collections.emptyList());

        String result = appointmentService.modifyAppointment(1L, newDate, newTimeSlot);

        assertEquals("Appointment modified successfully!", result);
        assertEquals(newDate, appointment.getDate());
        assertEquals(newTimeSlot, appointment.getTimeSlot());

        DoctorAvailability updatedAvailability = new DoctorAvailability();
        updatedAvailability.setDoctor(doctor);
        updatedAvailability.setDate(newDate);
        updatedAvailability.setTimeSlot(newTimeSlot);

        //verify(availabilityRepository).deleteByDoctorIdAndDateAndTimeSlot(1L, appointment.getDate(), appointment.getTimeSlot());
        verify(availabilityRepository).save(updatedAvailability);
        verify(appointmentRepository).save(appointment);
    }

    @Test
    void testCompleteAppointment() {
        Appointment appointment = new Appointment();
        appointment.setAppointmentId(1L);
        appointment.setStatus(Status.BOOKED);

        when(appointmentRepository.findByAppointmentId(1L)).thenReturn(Optional.of(appointment));

        String result = appointmentService.completeAppointment(1L);

        assertEquals("Appointment marked as completed!", result);
        assertEquals(Status.COMPLETED, appointment.getStatus());
        verify(appointmentRepository).save(appointment);
    }

    @Test
    void testGetUpcomingAppointments() {
        User patient = new User();
        patient.setId(1L);
        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setStatus(Status.BOOKED);

        when(appointmentRepository.findByPatientIdAndStatus(1L, Status.BOOKED)).thenReturn(List.of(appointment));

        List<Appointment> result = appointmentService.getUpcomingAppointments(1L);

        assertEquals(1, result.size());
        assertEquals(appointment, result.get(0));
    }

    @Test
    void testGetUpcomingAppointmentsForDoctor() {
        User doctor = new User();
        doctor.setId(1L);
        Appointment appointment = new Appointment();
        appointment.setDoctor(doctor);
        appointment.setStatus(Status.BOOKED);

        when(appointmentRepository.findByDoctorIdAndStatus(1L, Status.BOOKED)).thenReturn(List.of(appointment));

        List<Appointment> result = appointmentService.getUpcomingAppointmentsForDoctor(1L);

        assertEquals(1, result.size());
        assertEquals(appointment, result.get(0));
    }

    @Test
    void testGetCompletedAppointmentsForPatients() {
        User patient = new User();
        patient.setId(1L);
        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setStatus(Status.COMPLETED);

        when(appointmentRepository.findByPatientIdAndStatus(1L, Status.COMPLETED)).thenReturn(List.of(appointment));

        List<Appointment> result = appointmentService.getCompletedAppointmentsForPatients(1L);

        assertEquals(1, result.size());
        assertEquals(appointment, result.get(0));
    }

    @Test
    void testGetCompletedAppointmentsForDoctors() {
        User doctor = new User();
        doctor.setId(1L);
        Appointment appointment = new Appointment();
        appointment.setDoctor(doctor);
        appointment.setStatus(Status.COMPLETED);

        when(appointmentRepository.findByDoctorIdAndStatus(1L, Status.COMPLETED)).thenReturn(List.of(appointment));

        List<Appointment> result = appointmentService.getCompletedAppointmentsForDoctors(1L);

        assertEquals(1, result.size());
        assertEquals(appointment, result.get(0));
    }

    @Test
    void testGiveByAppointmentId() {
        Appointment appointment = new Appointment();
        appointment.setAppointmentId(1L);

        when(appointmentRepository.findByAppointmentId(1L)).thenReturn(Optional.of(appointment));

        Optional<Appointment> result = appointmentService.giveByAppointmentId(1L);

        assertTrue(result.isPresent());
        assertEquals(appointment, result.get());
    }
}
