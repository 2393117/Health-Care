package com.cts.healthcare;


import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.healthcare.entity.Consultation;
import com.cts.healthcare.repository.ConsultationRepository;
import com.cts.healthcare.service.ConsultationService;

@ExtendWith(MockitoExtension.class)
public class ConsultationServiceTest {

    @Mock
    private ConsultationRepository consultationRepository;

    @InjectMocks
    private ConsultationService consultationService;

    @Test
    void testSaveConsultation() {
        Consultation consultation = new Consultation();
        consultation.setConsultationId(1L);
        // Set other properties of consultation as needed

        consultationService.saveConsultation(consultation);
        verify(consultationRepository).save(consultation);
    }

    @Test
    void testGetConsultationByAppointmentId() {
        Consultation consultation = new Consultation();
        consultation.setConsultationId(1L);
        // Set other properties of consultation as needed

        Long appointmentId = 1L;
        Optional<Consultation> optionalConsultation = Optional.of(consultation);

        when(consultationRepository.findByAppointmentAppointmentId(appointmentId)).thenReturn(optionalConsultation);

        Optional<Consultation> result = consultationService.getConsultationByAppointmentId(appointmentId);

        assertTrue(result.isPresent());
        assertEquals(consultation, result.get());
    }
}
