package com.cts.healthcare;
import com.cts.healthcare.service.DoctorAvailabilityService;
import com.cts.healthcare.entity.DoctorAvailability;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.never;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.time.LocalDate;
import java.util.Optional;
import java.util.List;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.healthcare.entity.DoctorAvailability;
import com.cts.healthcare.entity.TimeSlot;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.repository.DoctorAvailabilityRepository;
import com.cts.healthcare.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
public class DoctorAvailabilityServiceTest {

    @Mock
    private DoctorAvailabilityRepository availabilityRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private DoctorAvailabilityService doctorAvailabilityService;

    @Test
    void testGetAvailabilityByDoctor() {
        Long doctorId = 1L;
        DoctorAvailability availability = new DoctorAvailability();
        availability.setDoctor(new User());
        availability.setDate(LocalDate.now());
        availability.setTimeSlot(TimeSlot.ELEVEN_AM);

        when(availabilityRepository.findByDoctorIdAndDateAndTimeSlot(doctorId, null, null))
            .thenReturn(List.of(availability));

        List<DoctorAvailability> result = doctorAvailabilityService.getAvailabilityByDoctor(doctorId);

        assertEquals(1, result.size());
        assertEquals(availability, result.get(0));
    }

    @Test
    void testBookAppointment() {
        Long doctorId = 1L;
        LocalDate date = LocalDate.now();
        TimeSlot timeSlot = TimeSlot.ELEVEN_AM;
        User doctor = new User();
        doctor.setId(doctorId);

        when(availabilityRepository.findByDoctorIdAndDateAndTimeSlot(doctorId, date, timeSlot))
            .thenReturn(Collections.emptyList());
        when(userRepository.findById(doctorId)).thenReturn(Optional.of(doctor));

        boolean result = doctorAvailabilityService.bookAppointment(doctorId, date, timeSlot);

        assertTrue(result);

        DoctorAvailability newAvailability = new DoctorAvailability();
        newAvailability.setDoctor(doctor);
        newAvailability.setDate(date);
        newAvailability.setTimeSlot(timeSlot);

        verify(availabilityRepository).save(newAvailability);
    }

    @Test
    void testBookAppointmentAlreadyBooked() {
        Long doctorId = 1L;
        LocalDate date = LocalDate.now();
        TimeSlot timeSlot = TimeSlot.ELEVEN_AM;
        DoctorAvailability availability = new DoctorAvailability();
        availability.setDoctor(new User());
        availability.setDate(date);
        availability.setTimeSlot(timeSlot);

        when(availabilityRepository.findByDoctorIdAndDateAndTimeSlot(doctorId, date, timeSlot))
            .thenReturn(List.of(availability));

        boolean result = doctorAvailabilityService.bookAppointment(doctorId, date, timeSlot);

        assertFalse(result);
        verify(availabilityRepository, never()).save(availability);
    }

    @Test
    void testCancelAppointment() {
        Long doctorId = 1L;
        LocalDate date = LocalDate.now();
        TimeSlot timeSlot = TimeSlot.ELEVEN_AM;
        DoctorAvailability availability = new DoctorAvailability();
        availability.setDoctor(new User());
        availability.setDate(date);
        availability.setTimeSlot(timeSlot);

        when(availabilityRepository.findByDoctorIdAndDateAndTimeSlot(doctorId, date, timeSlot))
            .thenReturn(List.of(availability));

        doctorAvailabilityService.cancelAppointment(doctorId, date, timeSlot);

        verify(availabilityRepository).delete(availability);
    }
}
