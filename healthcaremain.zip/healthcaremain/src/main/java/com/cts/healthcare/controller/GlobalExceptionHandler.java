package com.cts.healthcare.controller;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cts.healthcare.exception.AppointmentNotFoundException;
import com.cts.healthcare.exception.DoctorNotFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {

    // Handle generic exceptions
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public String handleGenericException(Exception ex, Model model) {
        model.addAttribute("error", "An unexpected error occurred: " + ex.getMessage());
        return "error"; // Return a generic error page
    }

    // Handle DoctorNotFoundException
    @ExceptionHandler(DoctorNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleDoctorNotFoundException(DoctorNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error"; // Return a specific error page
    }

    // Handle AppointmentNotFoundException
    @ExceptionHandler(AppointmentNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleAppointmentNotFoundException(AppointmentNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error"; // Return a specific error page
    }

    // Handle IllegalArgumentException (e.g., invalid input)
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handleIllegalArgumentException(IllegalArgumentException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error"; // Return a specific error page
    }

    // Handle other specific exceptions as needed
}