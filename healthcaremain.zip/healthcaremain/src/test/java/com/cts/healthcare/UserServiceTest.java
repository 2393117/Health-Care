package com.cts.healthcare;

import com.cts.healthcare.entity.Role;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.repository.RoleRepository;
import com.cts.healthcare.repository.UserRepository;
import com.cts.healthcare.service.UserService;
import org.junit.jupiter.api.BeforeEach;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.never;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.Optional;
import java.util.List;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.cts.healthcare.entity.Role;
import com.cts.healthcare.entity.User;
import com.cts.healthcare.repository.RoleRepository;
import com.cts.healthcare.repository.UserRepository;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @InjectMocks
    private UserService userService;

    @Test
    void testGetUserById() {
        User user = new User();
        user.setId(1L);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        Optional<User> result = userService.getUserById(1L);

        assertTrue(result.isPresent());
        assertEquals(user, result.get());
    }

    @Test
    void testGetUserByEmail() {
        User user = new User();
        user.setEmail("test@example.com");

        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(user));

        Optional<User> result = userService.getUserByEmail("test@example.com");

        assertTrue(result.isPresent());
        assertEquals(user, result.get());
    }

    @Test
    void testGetUsersByRole() {
        User user = new User();
        Role role = new Role();
        role.setName("ROLE_DOCTOR");
        user.setRole(role);

        when(userRepository.findByRole_Name("ROLE_DOCTOR")).thenReturn(List.of(user));

        List<User> result = userService.getUsersByRole("ROLE_DOCTOR");

        assertEquals(1, result.size());
        assertEquals(user, result.get(0));
    }

    @Test
    void testSaveUser() {
        User user = new User();
        user.setEmail("test@example.com");
        Role role = new Role();
        role.setName("ROLE_DOCTOR");
        user.setRole(role);

        when(roleRepository.findByName("ROLE_DOCTOR")).thenReturn(Optional.of(role));
        when(userRepository.save(user)).thenReturn(user);

        User result = userService.saveUser(user);

        assertEquals(user, result);
        verify(userRepository).save(user);
    }

    @Test
    void testGetDoctorsBySpecialization() {
        User user = new User();
        user.setSpecialization("Cardiology");

        when(userRepository.findBySpecialization("Cardiology")).thenReturn(List.of(user));

        List<User> result = userService.getDoctorsBySpecialization("Cardiology");

        assertEquals(1, result.size());
        assertEquals(user, result.get(0));
    }

    @Test
    void testGetLoggedInUser() {
        User user = new User();
        user.setEmail("test@example.com");

        Authentication authentication = org.mockito.Mockito.mock(Authentication.class);
        SecurityContext securityContext = org.mockito.Mockito.mock(SecurityContext.class);
        org.mockito.Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
        org.mockito.Mockito.when(authentication.getName()).thenReturn("test@example.com");
        SecurityContextHolder.setContext(securityContext);

        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(user));

        Optional<User> result = userService.getLoggedInUser();

        assertTrue(result.isPresent());
        assertEquals(user, result.get());
    }

    @Test
    void testInitializeRoles() {
        when(roleRepository.count()).thenReturn(0L);

        userService.initializeRoles();

        verify(roleRepository, times(1)).save(new Role(Role.ROLE_PATIENT, "Patient role with basic access"));
        verify(roleRepository, times(1)).save(new Role(Role.ROLE_DOCTOR, "Doctor role with medical access"));
    }
}
